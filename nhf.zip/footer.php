<footer class="text-center footer text-light bg-lightdark" >
  <div class="container pt-2">
    <section class="mb-2">
      <a
        class="btn btn-link btn-floating btn-lg text-light m-1"
        href="https://www.facebook.com/halasi.peterandras/"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <a
        class="btn btn-link btn-floating btn-lg text-light m-1"
        href="https://youtu.be/yPYZpwSpKmA?t=51"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-twitter"></i
      ></a>

      <a
        class="btn btn-link btn-floating btn-lg text-light m-1"
        href="https://youtu.be/dQw4w9WgXcQ"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-google"></i
      ></a>

      <a
        class="btn btn-link btn-floating btn-lg text-light m-1"
        href="https://www.instagram.com/spat3r/"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-instagram"></i
      ></a>

      <a
        class="btn btn-link btn-floating btn-lg text-light m-1"
        href="https://www.youtube.com/watch?v=fC7oUOUEEi4"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-linkedin"></i
      ></a>
      <a
        class="btn btn-link btn-floating btn-lg text-light m-1"
        href="https://github.com/spat3r"
        role="button"
        data-mdb-ripple-color="dark"
        ><i class="fab fa-github"></i
      ></a>
    </section>
  </div>

  <div class="text-center text-white p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2021 Copyright:
    <a class="text-light" href="https://www.facebook.com/whiteboysummer/">Später Inc.</a>
  </div>
</footer>
<?php mysqli_close($link) ?>
